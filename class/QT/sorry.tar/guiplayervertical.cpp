#include "guiplayervertical.h"

GUIPlayerVertical::GUIPlayerVertical( Player* p ) : GUIPlayer( p ) {

}
