#include "guiplayerhorizontal.h"

GUIPlayerHorizontal::GUIPlayerHorizontal( Player* p ) : GUIPlayer(p) {
}
