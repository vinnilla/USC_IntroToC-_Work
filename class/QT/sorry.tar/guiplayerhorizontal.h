#include <QtGui>

#ifndef GUIPLAYERHORIZONTAL_H
#define GUIPLAYERHORIZONTAL_H

#include "player.h"
#include "guiplayer.h"

class GUIPlayerHorizontal : public GUIPlayer {
  Q_OBJECT

  private:

 public:
    GUIPlayerHorizontal( Player* p );

};

#endif
