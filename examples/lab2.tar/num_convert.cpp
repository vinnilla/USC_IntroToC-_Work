#include <iostream>
#include <cmath>

using namespace std;
int main(int argc, char *argv[])
{
  // Declare any other variables you need here
  // and/or delete the integer declared below 
  int deleteme;

  
  // Prompt the user
  cout << "Enter a number:  ";

  // get input  
  cin >> deleteme;

  // Do some operations


  // Print the result to the user

  
  // You're done
  return 0;
  
}

