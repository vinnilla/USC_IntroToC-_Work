//checkingaccount.cpp

#include "checkingaccount.h"

using namespace std;

CheckingAccount::CheckingAccount() : BankAccount() {}

void CheckingAccount::writeCheck(int exchange) {}